// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Set current year in footer
    document.getElementById('currentYear').textContent = new Date().getFullYear();
    
    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const mobileNav = document.querySelector('.mobile-nav');
    
    if (mobileMenuToggle && mobileNav) {
        mobileMenuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            mobileNav.classList.toggle('active');
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                // Close mobile menu if open
                if (mobileMenuToggle && mobileMenuToggle.classList.contains('active')) {
                    mobileMenuToggle.classList.remove('active');
                    mobileNav.classList.remove('active');
                }
                
                const headerHeight = document.querySelector('.header').offsetHeight;
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerHeight;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Header scroll effect
    const header = document.getElementById('header');
    
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                header.style.padding = '0.75rem 0';
                header.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
            } else {
                header.style.padding = '1rem 0';
                header.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.1)';
            }
        });
    }
    
    // Accordion functionality
    const accordionHeaders = document.querySelectorAll('.accordion-header');
    
    accordionHeaders.forEach(header => {
        header.addEventListener('click', function() {
            this.classList.toggle('active');
            const content = this.nextElementSibling;
            
            if (this.classList.contains('active')) {
                content.classList.add('active');
            } else {
                content.classList.remove('active');
            }
        });
    });
    
    // Testimonials slider
    const testimonialTrack = document.querySelector('.testimonials-track');
    const testimonials = document.querySelectorAll('.testimonial');
    const dots = document.querySelectorAll('.dot');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    let currentIndex = 0;
    let intervalId;
    
    if (testimonialTrack && testimonials.length > 0) {
        // Update the testimonial slider
        function updateSlider() {
            const translateValue = -currentIndex * 100;
            testimonialTrack.style.transform = `translateX(${translateValue}%)`;
            
            // Update active dot
            dots.forEach((dot, index) => {
                if (index === currentIndex) {
                    dot.classList.add('active');
                } else {
                    dot.classList.remove('active');
                }
            });
        }
        
        // Next testimonial
        function nextTestimonial() {
            currentIndex = (currentIndex + 1) % testimonials.length;
            updateSlider();
        }
        
        // Previous testimonial
        function prevTestimonial() {
            currentIndex = (currentIndex - 1 + testimonials.length) % testimonials.length;
            updateSlider();
        }
        
        // Auto slide
        function startAutoSlide() {
            intervalId = setInterval(nextTestimonial, 5000);
        }
        
        function stopAutoSlide() {
            clearInterval(intervalId);
        }
        
        // Button event listeners
        if (prevBtn && nextBtn) {
            prevBtn.addEventListener('click', function() {
                stopAutoSlide();
                prevTestimonial();
                startAutoSlide();
            });
            
            nextBtn.addEventListener('click', function() {
                stopAutoSlide();
                nextTestimonial();
                startAutoSlide();
            });
        }
        
        // Dot navigation
        dots.forEach((dot, index) => {
            dot.addEventListener('click', function() {
                stopAutoSlide();
                currentIndex = index;
                updateSlider();
                startAutoSlide();
            });
        });
        
        // Touch events for mobile
        let touchStartX = 0;
        let touchEndX = 0;
        
        testimonialTrack.addEventListener('touchstart', function(e) {
            touchStartX = e.changedTouches[0].screenX;
            stopAutoSlide();
        }, { passive: true });
        
        testimonialTrack.addEventListener('touchend', function(e) {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
            startAutoSlide();
        }, { passive: true });
        
        function handleSwipe() {
            const swipeDistance = touchStartX - touchEndX;
            
            if (swipeDistance > 50) {
                nextTestimonial(); // Swipe left, show next
            } else if (swipeDistance < -50) {
                prevTestimonial(); // Swipe right, show previous
            }
        }
        
        // Start the automatic slider
        startAutoSlide();
    }
    
    // Animate elements when they are in viewport
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    function checkVisibility() {
        animatedElements.forEach(element => {
            const elementPosition = element.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            // If element is in viewport
            if (elementPosition.top < windowHeight * 0.85) {
                element.classList.add('visible');
            }
        });
    }
    
    // Run on load
    checkVisibility();
    
    // Run on scroll
    window.addEventListener('scroll', checkVisibility);
    
    // Client counter animation
    const counterElement = document.getElementById('clientCounter');
    
    if (counterElement) {
        let hasAnimated = false;
        
        function animateCounter() {
            const elementPosition = counterElement.getBoundingClientRect();
            const windowHeight = window.innerHeight;
            
            if (elementPosition.top < windowHeight * 0.85 && !hasAnimated) {
                hasAnimated = true;
                
                const targetCount = 1000;
                let currentCount = 0;
                const duration = 2000; // 2 seconds
                const interval = 15; // Update every 15ms
                const increment = targetCount / (duration / interval);
                
                const counter = setInterval(() => {
                    currentCount += increment;
                    
                    if (currentCount >= targetCount) {
                        clearInterval(counter);
                        currentCount = targetCount;
                    }
                    
                    counterElement.textContent = Math.round(currentCount);
                }, interval);
            }
        }
        
        // Run on load
        animateCounter();
        
        // Run on scroll
        window.addEventListener('scroll', animateCounter);
    }
    
    // Form validation - Waitlist form
    const waitlistForm = document.getElementById('waitlistForm');
    
    if (waitlistForm) {
        waitlistForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const emailInput = document.getElementById('waitlistEmail');
            const errorMessage = document.getElementById('waitlistEmailError');
            let isValid = true;
            
            // Simple email validation
            if (!isValidEmail(emailInput.value.trim())) {
                errorMessage.textContent = 'Please enter a valid email address';
                errorMessage.style.display = 'block';
                isValid = false;
            } else {
                errorMessage.style.display = 'none';
            }
            
            if (isValid) {
                // Form is valid, show success message
                alert('Thank you for joining our waitlist!');
                waitlistForm.reset();
            }
        });
    }
    
    // Priority waitlist form
    const priorityWaitlistForm = document.getElementById('priorityWaitlistForm');
    
    if (priorityWaitlistForm) {
        priorityWaitlistForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const nameInput = document.getElementById('waitlistName');
            const emailInput = document.getElementById('waitlistEmail2');
            const nameError = document.getElementById('waitlistNameError');
            const emailError = document.getElementById('waitlistEmail2Error');
            let isValid = true;
            
            // Name validation
            if (nameInput.value.trim() === '') {
                nameError.textContent = 'Please enter your name';
                nameError.style.display = 'block';
                isValid = false;
            } else {
                nameError.style.display = 'none';
            }
            
            // Email validation
            if (!isValidEmail(emailInput.value.trim())) {
                emailError.textContent = 'Please enter a valid email address';
                emailError.style.display = 'block';
                isValid = false;
            } else {
                emailError.style.display = 'none';
            }
            
            if (isValid) {
                // Form is valid, show success message
                alert('Thank you for joining our priority waitlist!');
                priorityWaitlistForm.reset();
            }
        });
    }
    
    // Form validation - Booking form
    const bookingForm = document.getElementById('bookingForm');
    
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');
            const serviceInput = document.getElementById('service');
            const dateTimeInput = document.getElementById('dateTime');
            
            const nameError = document.getElementById('nameError');
            const emailError = document.getElementById('emailError');
            const serviceError = document.getElementById('serviceError');
            const dateTimeError = document.getElementById('dateTimeError');
            
            let isValid = true;
            
            // Name validation
            if (nameInput.value.trim() === '') {
                nameError.textContent = 'Please enter your name';
                nameError.style.display = 'block';
                isValid = false;
            } else {
                nameError.style.display = 'none';
            }
            
            // Email validation
            if (!isValidEmail(emailInput.value.trim())) {
                emailError.textContent = 'Please enter a valid email address';
                emailError.style.display = 'block';
                isValid = false;
            } else {
                emailError.style.display = 'none';
            }
            
            // Service validation
            if (serviceInput.value === '') {
                serviceError.textContent = 'Please select a service';
                serviceError.style.display = 'block';
                isValid = false;
            } else {
                serviceError.style.display = 'none';
            }
            
            // Date and time validation
            if (dateTimeInput.value === '') {
                dateTimeError.textContent = 'Please select a date and time';
                dateTimeError.style.display = 'block';
                isValid = false;
            } else {
                dateTimeError.style.display = 'none';
            }
            
            if (isValid) {
                // Form is valid, show success message
                alert('Thank you for booking an appointment! We will confirm your appointment shortly.');
                bookingForm.reset();
            }
        });
    }
    
    // Validate email format
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
});